<!doctype html>
<html lang="en">

<head>
<?php require_once(APPPATH . 'views/includes/css.php'); ?>
<title>Gyana Vana Foundation</title>
</head>
<body>
<section class="banner">
<?php require_once(APPPATH . 'views/includes/menu.php'); ?>
</section>
<?php require_once(APPPATH . 'views/includes/footer.php'); ?>
<style>
  a.nav-link.hactive:before{
  width: 75%;
  }
</style>
</body>

</html>