import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.css'],
})
export class MasterComponent implements OnInit {
  constructor(private client: HttpClient) {}
  // readonly url = `http://192.168.1.204:8080/admin/post_service_videos`;
  readonly url = `https://gyanavana.php.ymtsindia.org:8085/admin/post_service_videos`
  video: any = {};
  data: FormData = new FormData();

  ngOnInit(): void {}

  onFileSelected(event: any) {
    this.data.append('video', event.target.files[0]);
  }

  postVideo() {
    this.data.append('videoTitle', this.video.title);
    this.data.append('description', this.video.description);

    //sending post request
    this.client.post(this.url, this.data).subscribe({
      next: (res) => {
        alert('Video uploaded successfully');
        this.data.forEach((value, key) => {
          this.data.delete(key);
        });
      },
      error: (err) => {
        alert('Error uploading video');
      },
    });
  }
}
