import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css'],
})
export class SidenavComponent implements OnInit {
  viewbig: boolean = true;
  
  showsidnav() {
    this.viewbig = !this.viewbig;
  }
  constructor() {}

  ngOnInit(): void {
    let arrow: NodeListOf<Element> = document.querySelectorAll(".drop");

    for (let i: number = 0; i < arrow.length; i++) {
      arrow[i].addEventListener("click", (e: Event) => {
        let arrowParent: HTMLElement = (<HTMLElement>e.target).parentElement!.parentElement as HTMLElement;
        arrowParent.classList.toggle("showMenu");
      });
    }
  }
}

