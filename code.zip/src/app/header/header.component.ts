import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  viewbig: boolean = true;
  
  showsidnav() {
    this.viewbig = !this.viewbig;
    var element = <HTMLAnchorElement>document.querySelector('#sidbar');
    element?.classList.toggle('close');
    var element = <HTMLAnchorElement>document.querySelector('#main-content-wrapper');
    element?.classList.toggle('mini-menu');
  }
  constructor() { }

  ngOnInit(): void {
  }

}
